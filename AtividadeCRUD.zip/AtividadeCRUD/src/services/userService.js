const prisma = require('../config/database');
const bcrypt = require('bcryptjs');



const UserService = {
    async getAllUsers() {
        return await prisma.user.findMany();
    },

    async getUserById(userId) {
        return await prisma.user.findUnique({ where: { id: Number(userId) } });
    },

    async getUserByEmail(email) {
        return await prisma.user.findUnique({ where: { email } });
    },

    async addUser({ name, email, password }) {
        const existingUser = await prisma.user.findUnique({ where: { email } });
        if (existingUser) {
            throw new Error('Usuário já existe com esse e-mail.');
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        return await prisma.user.create({
            data: { name, email, password: hashedPassword }
        });
    },
    async addUsuario({ name, email, password , fone , endereco}) {
        const existingUser = await prisma.user.findUnique({ where: { email } });
        if (existingUser) {
            throw new Error('Usuário já existe com esse e-mail.');
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        return await prisma.user.create({
            data: { name, email, password: hashedPassword, fone , endereco }
        });
    },
    

    async updateUser(userId, { name, email , fone , endereco}) {
        return await prisma.user.update({
            where: { id: Number(userId) },
            data: { name, email, fone , endereco }
        });
    },

    async deleteUser(userId) {
        return await prisma.user.delete({ where: { id: Number(userId) } });
    },

    
};

module.exports = UserService;
