const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const user = require("./routes/routes");
const userController = require('./controllers/userController');
const app = express();

app.set('view engine', 'ejs');


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public')); 

app.use(session({
    secret: 'batata', 
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } 
}));

app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    next();
});

app.get("/", (req, res) => {
    res.redirect("/login");
});
console.log("Rotas carregadas!");

app.use(user);


app.listen(2000, () => {
    console.log('Servidor rodando na porta 2000');
});
