const bcrypt = require('bcryptjs');
const UserService = require('../services/userService');

exports.getAllUsers = async (req, res) => {
    const users = await UserService.getAllUsers();
    res.render('index', { users });
};

exports.getUserById = async (req, res) => {
    const userId = req.params.id;
    const user = await UserService.getUserById(userId);
    res.render('edit', { user });
};

exports.getdeleteByUser = async (req, res) => {
    const userId = req.params.id;
    const user = await UserService.getUserById(userId);
    res.render('dell', { user });
};

exports.registerUser = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        if (!name || !email || !password) {
            return res.status(400).send("Preencha todos os campos.");
        }

        const existingUser = await UserService.getUserByEmail(email);
        if (existingUser) {
            return res.status(400).send("E-mail já cadastrado.");
        }

        const newUser = await UserService.addUser({ name, email, password });

        req.session.user = newUser;

        res.redirect('/');
    } catch (error) {
        console.error(error);
        res.status(500).send('Erro ao registrar e autenticar usuário.');
    }
};

exports.add = async (req, res) => {
    try {
        const { name, email, fone ,endereco ,password } = req.body;

        if (!name || !email || !fone || !endereco || !password) {
            return res.status(400).send("Preencha todos os campos.");
        }

        const existingUser = await UserService.getUserByEmail(email);
        if (existingUser) {
            return res.status(400).send("E-mail já cadastrado.");
        }

        const newUser = await UserService.addUsuario({ name, email, password, fone , endereco });

        req.session.user = newUser;

        res.redirect('/users');
    } catch (error) {
        console.error(error);
        res.status(500).send('Erro ao registrar e autenticar usuário.');
    }
};


exports.updateUser = async (req, res) => {
    try {
        const userId = req.params.id;
        const { name, email , fone , endereco } = req.body;
        await UserService.updateUser(userId, { name, email , fone , endereco });
        res.redirect('/users');
    } catch (error) {
        console.error(error);
        res.status(500).send('Erro ao atualizar usuário.');
    }
};

exports.deleteUser = async (req, res) => {
    try {
        const userId = req.params.id;
        await UserService.deleteUser(userId);
        res.redirect('/users');
    } catch (error) {
        console.error(error);
        res.status(500).send('Erro ao deletar usuário.');
    }
};

exports.showLoginPage = (req, res) => {
    res.render('login', { error: req.query.error || null });
};

exports.showRegisterPage = (req, res) => {
    res.render('register');
};

exports.loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await UserService.getUserByEmail(email);
        
        if (!user) {
            return res.send('Usuário não encontrado.');
        }
        
        const match = await bcrypt.compare(password, user.password);
        
        if (match) {
            req.session.user = user;
            res.redirect('/users');
        } else {
            res.send('Senha incorreta.');
        }
    } catch (error) {
        console.error(error);
        res.status(500).send('Erro ao processar login.');
    }
};
exports.showAddPage = (req, res) => {
    res.render('add', { error: req.query.error || null });
};


exports.logoutUser = (req, res) => {
    req.session.destroy(() => {
        res.redirect('/login');
    });
};
